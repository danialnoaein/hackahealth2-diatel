<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-28 00:18:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/opt/alt/php70/usr/lib64/php/modules/ffmpeg.so' - libswscale.so.3: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-28 00:18:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/opt/alt/php70/usr/lib64/php/modules/ffmpeg.so' - libswscale.so.3: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-28 00:18:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/opt/alt/php70/usr/lib64/php/modules/ffmpeg.so' - libswscale.so.3: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-28 00:18:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/opt/alt/php70/usr/lib64/php/modules/ffmpeg.so' - libswscale.so.3: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-28 00:18:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/opt/alt/php70/usr/lib64/php/modules/ffmpeg.so' - libswscale.so.3: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2019-04-28 00:18:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/opt/alt/php70/usr/lib64/php/modules/ffmpeg.so' - libswscale.so.3: cannot open shared object file: No such file or directory Unknown 0
