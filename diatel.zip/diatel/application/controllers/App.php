<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class App extends CI_Controller {

	function __construct(){
        parent::__construct();
        $this->load->model('app_model');
    }

	public function index(){
        echo "درحال توسعه";
    }

    public function registerCheckup(){

        $userInfo = $this->app_model->get_user_info( $this->input->post("userId") );
        $username = "همیارشما";

        if ( $this->input->post("dangerLevel") == 1 || $this->input->post("dangerLevel") == 2 ) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL,"https://api.kavenegar.com/v1/77747839513752695548566B4448706C6F31355A6635522F66542B5A4A46394D/verify/lookup.json");
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS,
                        "receptor=" . $userInfo["nursePhoneNumber"] . "&token=" . str_replace(' ', '', $userInfo["name"]) . "&template=diatel-danger");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $server_output = curl_exec($ch);
            curl_close ($ch);
            
        }

        $user = array(
            'bloodSuger' => $this->input->post("bloodSuger"),
            'checkupTime' => $this->input->post("checkupTime"),
            'frequentUrination' => $this->input->post("frequentUrination"),
            'dryMouth' => $this->input->post("dryMouth"),
            'excessiveThirst' => $this->input->post("excessiveThirst"),
            'suddenFeeling' => $this->input->post("suddenFeeling"),
            'feelingBurningHands' => $this->input->post("feelingBurningHands"),
            'dangerLevel' => $this->input->post("dangerLevel"),
            'userId' => $this->input->post("userId"),
            'createdAt' => time()
        );
        $regResult = $this->app_model->register_checkup( $user );
        var_dump( $userInfo);

    }

    public function registerUser ( ){

        $user = array(
            'name' => $this->input->post("name"),
            'age' => $this->input->post("age"),
            'gender' => $this->input->post("gender"),
            'height' => $this->input->post("height"),
            'weight' => $this->input->post("weight"),
            'diseaseHistory' => $this->input->post("diseaseHistory"),
            'familyDisease' => $this->input->post("familyDisease"),
            'diabetType' => $this->input->post("diabetType"),
            'phoneNumber' => $this->input->post("phoneNumber"),
            'nursePhoneNumber' => $this->input->post("nursePhoneNumber"),
            'createdAt' => time(),
            'updatedAt' => time()
        );
        $regResult = $this->app_model->register_user( $user );
        echo $regResult;

    }
}
