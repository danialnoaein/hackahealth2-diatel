<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class App_model extends MY_Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function getUser(){
        $this->db->select('*');
        $this->db->from('user');
        $query = $this->db->get();

        if($query->num_rows()>0){

            $userInfo = array();
            foreach ($query->result() as $row)
            {
                $userInfo[$row->id] = array(
                    'name' => $row->name,
                    'id' => $row->id
                );

            }
            return $userInfo;
        }
        else
        {
            return 'No Data';
        }
    }

    public function get_user_info( $userId ){
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('id' , $userId);
        $query = $this->db->get();

        if($query->num_rows()>0){

            $userInfo = array();
            foreach ($query->result() as $row){
                // $userInfo[$row->id] = array(
                //     'nursePhoneNumber' => $row->nursePhoneNumber,
                //     'name' => $row->name,
                //     'id' => $row->id
                // );

                $userInfo['nursePhoneNumber'] = $row->nursePhoneNumber;
                $userInfo['name'] = $row->name;
                $userInfo['id'] = $row->id;

            }
            return $userInfo;
            
        }
        else{
            return 'No Data';
        }
    }

    public function register_user($user){
        $this->db->insert('user', $user);
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }

    public function register_checkup($checkup_data){
        $this->db->insert('checkup', $checkup_data);
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }

}